import { useState } from 'react';
import { motion } from 'framer-motion';
import { Phone, Mail, MapPin, Send, Clock, ArrowRight } from 'lucide-react';
import { SectionWrapper, Container } from '../components/SectionWrapper';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const contactInfo = [
  {
    icon: Phone,
    label: 'Phone',
    value: '+91 80932 84061',
    href: 'tel:+918093284061'
  },
  {
    icon: Mail,
    label: 'Email',
    value: 'info@ytstack.in',
    href: 'mailto:info@ytstack.in'
  },
  {
    icon: MapPin,
    label: 'Address',
    value: '31, Chowringhee Road, Park Street, Kolkata-700016',
    href: 'https://maps.google.com/?q=31+Chowringhee+Road+Park+Street+Kolkata'
  },
  {
    icon: Clock,
    label: 'Working Hours',
    value: 'Mon - Sat: 10:00 AM - 7:00 PM',
    href: null
  }
];

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const response = await fetch(`${BACKEND_URL}/api/contact`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          subject: formData.subject,
          message: formData.message
        })
      });
      
      if (response.ok) {
        toast.success('Message sent successfully! We\'ll get back to you within 24 hours.');
        setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
      } else {
        const error = await response.json();
        toast.error(error.detail || 'Failed to send message. Please try again.');
      }
    } catch (error) {
      toast.error('Failed to send message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main data-testid="contact-page">
      <div className="noise-overlay" />
      
      {/* Hero */}
      <section className="pt-32 pb-16 relative overflow-hidden">
        <div className="gradient-orb gradient-orb-blue w-96 h-96 -top-48 -right-48" />
        <Container>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-3xl"
          >
            <span className="font-mono text-xs uppercase tracking-widest text-primary mb-4 block">
              Contact Us
            </span>
            <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tighter text-white mb-6">
              Let's Start a
              <br />
              <span className="text-primary">Conversation</span>
            </h1>
            <p className="text-slate-400 text-lg leading-relaxed">
              Have a project in mind? We'd love to hear about it. Get in touch and let's 
              discuss how we can help bring your vision to life.
            </p>
          </motion.div>
        </Container>
      </section>

      {/* Contact Section */}
      <SectionWrapper className="bg-slate-950 pt-8">
        <Container>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:col-span-1"
            >
              <h2 className="font-heading text-2xl font-bold text-white mb-8">Get In Touch</h2>
              
              <div className="space-y-6 mb-8">
                {contactInfo.map((info, index) => (
                  <motion.div
                    key={info.label}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    data-testid={`contact-info-${info.label.toLowerCase().replace(' ', '-')}`}
                  >
                    {info.href ? (
                      <a 
                        href={info.href}
                        target={info.label === 'Address' ? '_blank' : undefined}
                        rel={info.label === 'Address' ? 'noopener noreferrer' : undefined}
                        className="flex items-start gap-4 group"
                      >
                        <div className="w-12 h-12 border border-white/20 flex items-center justify-center flex-shrink-0 group-hover:border-primary group-hover:bg-primary/10 transition-all">
                          <info.icon size={20} className="text-primary" strokeWidth={1.5} />
                        </div>
                        <div>
                          <div className="font-mono text-xs uppercase tracking-wider text-slate-500 mb-1">
                            {info.label}
                          </div>
                          <div className="text-white group-hover:text-primary transition-colors">
                            {info.value}
                          </div>
                        </div>
                      </a>
                    ) : (
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 border border-white/20 flex items-center justify-center flex-shrink-0">
                          <info.icon size={20} className="text-primary" strokeWidth={1.5} />
                        </div>
                        <div>
                          <div className="font-mono text-xs uppercase tracking-wider text-slate-500 mb-1">
                            {info.label}
                          </div>
                          <div className="text-white">{info.value}</div>
                        </div>
                      </div>
                    )}
                  </motion.div>
                ))}
              </div>

              {/* Social Links */}
              <div>
                <h4 className="font-mono text-xs uppercase tracking-wider text-slate-500 mb-4">Follow Us</h4>
                <div className="flex gap-4">
                  <a 
                    href="https://github.com/Yash-0810" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 border border-white/20 flex items-center justify-center hover:border-primary hover:bg-primary/10 transition-all"
                    data-testid="contact-github"
                  >
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                    </svg>
                  </a>
                  <a 
                    href="https://www.linkedin.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 border border-white/20 flex items-center justify-center hover:border-primary hover:bg-primary/10 transition-all"
                    data-testid="contact-linkedin"
                  >
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
                    </svg>
                  </a>
                  <a 
                    href="https://twitter.com" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-10 h-10 border border-white/20 flex items-center justify-center hover:border-primary hover:bg-primary/10 transition-all"
                    data-testid="contact-twitter"
                  >
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                    </svg>
                  </a>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="lg:col-span-2"
            >
              <div className="glass p-8 md:p-10">
                <h2 className="font-heading text-2xl font-bold text-white mb-2">Send Us a Message</h2>
                <p className="text-slate-400 text-sm mb-8">Fill out the form below and we'll get back to you within 24 hours.</p>
                
                <form onSubmit={handleSubmit} className="space-y-6" data-testid="contact-form">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="font-mono text-xs uppercase tracking-wider text-slate-400 mb-2 block">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-primary transition-colors"
                        placeholder="John Doe"
                        data-testid="contact-name-input"
                      />
                    </div>
                    <div>
                      <label className="font-mono text-xs uppercase tracking-wider text-slate-400 mb-2 block">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-primary transition-colors"
                        placeholder="john@example.com"
                        data-testid="contact-email-input"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="font-mono text-xs uppercase tracking-wider text-slate-400 mb-2 block">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-primary transition-colors"
                        placeholder="+91 98765 43210"
                        data-testid="contact-phone-input"
                      />
                    </div>
                    <div>
                      <label className="font-mono text-xs uppercase tracking-wider text-slate-400 mb-2 block">
                        Subject *
                      </label>
                      <input
                        type="text"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        required
                        className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-primary transition-colors"
                        placeholder="Project Inquiry"
                        data-testid="contact-subject-input"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="font-mono text-xs uppercase tracking-wider text-slate-400 mb-2 block">
                      Your Message *
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows={6}
                      className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-primary transition-colors resize-none"
                      placeholder="Tell us about your project..."
                      data-testid="contact-message-input"
                    />
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full md:w-auto bg-primary text-white px-10 py-4 font-mono text-sm uppercase tracking-wider hover:bg-primary/90 transition-all hover:shadow-[0_0_20px_rgba(37,99,235,0.5)] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                    data-testid="contact-submit-btn"
                  >
                    {isSubmitting ? 'Sending...' : 'Send Message'}
                    <Send size={16} />
                  </button>
                </form>
              </div>
            </motion.div>
          </div>
        </Container>
      </SectionWrapper>

      {/* Map Section */}
      <SectionWrapper className="bg-slate-900/30">
        <Container>
          <div className="glass overflow-hidden">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.2363492908897!2d88.34815931495991!3d22.56520798517892!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a0277b75f1bb0e3%3A0x6a4a8d9a9e2d2d5a!2sChowringhee%20Rd%2C%20Kolkata%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1650000000000!5m2!1sen!2sin"
              width="100%"
              height="400"
              style={{ border: 0, filter: 'grayscale(100%) invert(92%) contrast(83%)' }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="YTSTACK Location"
              data-testid="contact-map"
            />
          </div>
        </Container>
      </SectionWrapper>
    </main>
  );
};

export default ContactPage;
